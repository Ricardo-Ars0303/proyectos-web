//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://i.ytimg.com/vi/xE6iyiQr7Oc/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLApyi1uKnvO9OYyvtmgyW8l3db93w",
  "https://www.elcarrocolombiano.com/wp-content/uploads/2022/05/21052022-PORTADA-Aston-Martin-DB5.jpg",
  "https://bonhamscarsonline.twic.pics/da27370c-c90b-4665-852f-fb3f92830246/preview-f23d66dc-eb8f-4fe1-b8b2-3bf1d26ffd62.jpg?twic=v1/resize=650/quality=90&twic=v1/cover=800x485",
  "https://amian-collectioncars.com/wp-content/uploads/2024/09/DSC06517.jpg",
  "https://acnews.blob.core.windows.net/imgnews/medium/NAZ_729b4047cc394d00b8f5600ca8f9159f.webp",
  "https://i.blogs.es/7249a4/mercedes-amg-gt-63-s-e-performance-mexico_/1366_521.jpg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});
     