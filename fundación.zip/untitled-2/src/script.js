// Menú móvil
const btnMenu = document.getElementById('btnMenu');
const mainNav = document.getElementById('mainNav');
btnMenu?.addEventListener('click', ()=> mainNav.classList.toggle('show'));

// Año en footer
document.getElementById('year').textContent = new Date().getFullYear();

// Noticias demo (imágenes diferenciadas a programas)
const API_POSTS = 'https://jsonplaceholder.typicode.com/posts?_limit=3';

function createNews(post){
  const wrap = document.createElement('article');
  wrap.className = 'card news-item';
  const seed = `nota-${post.id}`;
  wrap.innerHTML = `
    <img loading="lazy" src="https://picsum.photos/seed/${seed}/600/300" alt="Noticia">
    <div style="padding:12px 14px">
      <h4 style="margin:0">${post.title}</h4>
      <p>${post.body.slice(0,140)}${post.body.length>140?'…':''}</p>
    </div>
  `;
  return wrap;
}

fetch(API_POSTS)
  .then(r => r.json())
  .then(posts => {
    const container = document.getElementById('news');
    container.innerHTML = '';
    posts.forEach(p => container.appendChild(createNews(p)));
  })
  .catch(() => {
    const container = document.getElementById('news');
    container.innerHTML = '<div class="card" style="padding:14px">No se pudieron cargar las noticias.</div>';
  });

// Formularios demo
document.getElementById('donate-form')?.addEventListener('submit', (e)=>{
  e.preventDefault();
  alert('¡Gracias por tu apoyo! (Demo)');
  e.target.reset();
});

document.getElementById('contact-form')?.addEventListener('submit', (e)=>{
  e.preventDefault();
  alert('¡Mensaje enviado! (Demo)');
  e.target.reset();
});
